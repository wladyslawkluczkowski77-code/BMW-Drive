BMW Drive — projekt Android + automatyczne budowanie w chmurze

WAŻNE: ten ZIP nie zawiera gotowego APK/AAB. Workflow GitHub Actions buduje testowy APK i debugowy AAB; debugowy AAB NIE jest gotowy do publikacji produkcyjnej w Google Play.

Jak uruchomić budowanie z samego telefonu:
1. Zaloguj się lub utwórz konto na https://github.com/
2. W przeglądarce GitHub utwórz nowe repozytorium, np. BMW-Drive. Ustaw je jako Private.
3. Wejdź do repozytorium i wybierz Add file > Upload files.
4. Rozpakuj ZIP na telefonie (np. aplikacją Pliki), a następnie wgraj zawartość folderu BMW_Drive_Android do repozytorium. Ważne: wgraj też ukryty folder .github z workflow android-build.yml.
5. Zatwierdź zmiany (Commit changes).
6. Otwórz zakładkę Actions w repozytorium i wybierz workflow „Build BMW Drive Android”. Jeśli nie wystartuje sam, wybierz Run workflow.
7. Po zakończeniu wybierz uruchomione zadanie, przewiń do Artifacts i pobierz „BMW-Drive-builds”. Rozpakuj ZIP artifactów, by znaleźć APK do testów.

Do Google Play:
- Nowa gra wymaga pakietu Android App Bundle (.aab), ale do publikacji musi on być poprawnie podpisany kluczem wydawcy.
- Workflow obecnie tworzy pliki debugowe do testów, nie podpisany pakiet produkcyjny.
- Nie udostępniaj publicznie klucza podpisującego ani haseł. Repozytorium warto ustawić jako Private.
- Google Play może wymagać testów, deklaracji, zrzutów ekranu, ikony, polityki prywatności i innych informacji w Play Console.
- W obecnym prototypie Three.js jest pobierany z CDN, więc gra wymaga internetu.

Wymagania projektu:
- Android target API 36 (wymóg dla nowych aplikacji od 31 sierpnia 2026 r.).
